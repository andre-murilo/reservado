public class Application
{
    public Application()
    {

    }

    
    public void Initialize()
    {
        System.out.println("Simple WebServer");


        WebServer server = new WebServer(8080);
        if(!server.Initialize()) {
            System.out.println("Failed to inialize server");
            return;
        }
        
        server.Run();
    }
}